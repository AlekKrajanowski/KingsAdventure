﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KingsAdventure
{
    public class ProgressBar
    {
        public int PercentComplete { get; set; }
    }
}
